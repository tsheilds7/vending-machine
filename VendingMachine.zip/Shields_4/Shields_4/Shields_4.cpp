/**
Vending Machine
Purpose: Provides items such as snacks, beverages, alcohol, cigarettes and 
lottery tickets to consumers after money,
a credit card, or specially designed card is inserted into the machine.

@author Tilmon Shields
@version 1.0 03/06/18
*/



/*
***********************************
The Headers
***********************************
*/

#include "stdafx.h"
#include <chrono>
#include <thread>
#include <iostream>
#include <string>
#include <iomanip>

/*
***********************************
The Exit Function
***********************************
*/


void exit()
{

	std::cout << "\n";
	std::cout << "Goodbye\n";
	
	std::this_thread::sleep_for(std::chrono::milliseconds(5000));

	EXIT_SUCCESS;
}

/*
***********************************
The fuction that actually does the transaction.
***********************************
*/

void vending(double cost, std::string item)
{
	std::cout.precision(2);
	std::cout << "$" << std::fixed << cost << " is now being charged\n";

	std::this_thread::sleep_for(std::chrono::milliseconds(5000));

	std::cout << "\n";
	std::cout << "Now Vending " << item << " ...\n";

	std::this_thread::sleep_for(std::chrono::milliseconds(5000));
	
	exit();
}


/*
***********************************
The SubCategory Functions of types of Foods or Drinks


All basically the same just chooses the type of food or drink 
then calls the vending or exit function depending on what you choose.
***********************************
*/


/*
***********************************
Bevarage Function
***********************************
*/
void beverage()
{


	std::cout
		<<
		"\n " << "1: Coca-Cola -$2.00 \n" <<
		"\n " << "2: Sprite -$1.75 \n" <<
		"\n " << "3: Dr. Pepper -$1.50 \n" <<
		"\n " << "4: Dasani Water -$1.00 \n" <<
		"\n " << "5: Vitamin Water -$1.50 \n" <<
		"\n " << "6: Exit " << "\n"
		<<
		std::endl;


	int itemType;
	std::cin >> itemType;
	std::cout << "\n";
	switch (itemType)
	{

	case 1:
		vending(2.00, "Coca-Cola");
		break;

	case 2:
		vending(1.75, "Sprite");
		break;

	case 3:
		vending(1.50, "Dr. Pepper");
		break;

	case 4:
		vending(1.00, "Dasani Water");
		break;

	case 5:
		vending(1.50, "Vitamin Water");
		break;

	case 6:
		exit();
		break;

	default:
		std::cout << "Please choose a button from the menu\n";
		break;


	}
}

/*
***********************************
Baked Goods Function
***********************************
*/

void bakedGoods()
{


	std::cout
		<<
		"\n " << "1: Honey-Bun -$1.25 \n" <<
		"\n " << "2: Oatmeal Pie -$1.00 \n" <<
		"\n " << "3: Twinkie -$1.75 \n" <<
		"\n " << "4: Cookie -$2.00 \n" <<
		"\n " << "5: Muffin -$1.50 \n" <<
		"\n " << "6: Exit " << "\n"
		<<
		std::endl;

	

	
		int itemType;
		std::cin >> itemType;
		std::cout << "\n";
		switch (itemType)
		{

		case 1:
			vending(1.25, "Honey-Bun");
			
			break;

		case 2:
			vending(1.00, "Oatmeal Pie");
			break;

		case 3:
			vending(1.75, "Twinkie");
			break;

		case 4:
			vending(2.00, "Cookie");
			break;

		case 5:
			vending(1.50, "Muffin");
			break;

		case 6:
			exit();
			
			break;

		default:
			std::cout << "Please choose a button from the menu\n";
			break;

		}

	
}

/*
***********************************
Fruit Function
***********************************
*/

void fruits()
{


	std::cout
		<<
		"\n " << "1: Apple -$1.00 \n" <<
		"\n " << "2: Bananna -$.50 \n" <<
		"\n " << "3: Pear -$.75 \n" <<
		"\n " << "4: Grapes -$1.00 \n" <<
		"\n " << "5: Strawberries -$1.50 \n" <<
		"\n " << "6: Exit " << "\n"
		<<
		std::endl;

	

	
		int itemType;
		std::cin >> itemType;
		std::cout << "\n";
		switch (itemType)
		{

		case 1:
			vending(1.00, "Apple");
			break;

		case 2:
			vending(.50, "Bananna");
			break;

		case 3:
			vending(.75, "Pear");
			break;

		case 4:
			vending(1.00, "Grapes");
			break;

		case 5:
			vending(1.50, "Strawberries");
			break;

		case 6:
			exit();
			
			break;

		default:
			std::cout << "Please choose a button from the menu\n";
			break;


		}

	
}

/*
***********************************
Candy Function
***********************************
*/

void candy()
{


	std::cout
		<<
		"\n " << "1: Snickers -$1.25 \n" <<
		"\n " << "2: Jolly Rancher -$.50 \n" <<
		"\n " << "3: Butter Finger -$1.00 \n" <<
		"\n " << "4: Kit-Kat Bar -$1.25 \n" <<
		"\n " << "5: Twix Bar -$1.00 \n" <<
		"\n " << "6: Exit " << "\n"
		<<
		std::endl;

	

	
		int itemType;
		std::cin >> itemType;
		std::cout << "\n";
		switch (itemType)
		{

		case 1:
			vending(1.25, "Snickers");
			break;

		case 2:
			vending(.50, "Jolly Rancher");
			break;

		case 3:
			vending(1.00, "Butter Finger");
			break;

		case 4:
			vending(1.25, "Kit-Kat Bar");
			break;

		case 5:
			vending(1.00, "Twix Bar");
			break;

		case 6:
	
			exit();
			
			break;

		default:
			std::cout << "Please choose a button from the menu\n";
			break;
		}

	
}

/*
***********************************
Main Menu Function
***********************************
*/

void mainMenu()
{

	std::cout 
		<< 
		"\n " << "1: Beverages \n" <<
		"\n " << "2: Baked Goods \n" <<
		"\n " << "3: Fruits \n" <<
		"\n " << "4: Candy \n" <<
		"\n " << "5: Exit " << "\n" 
		<<
	std::endl;

	bool picked = false;

	do
	{
		int itemType;
		std::cin >> itemType;
		switch(itemType)
		{

		case 1:
			beverage();
			picked = true;
			break;

		case 2:
			bakedGoods();
			picked = true;
			break;

		case 3:
			fruits();
			picked = true;
			break;

		case 4:
			candy();
			picked = true;
			break;

		case 5:
			exit();
			picked = true;
			break;


		default:
			std::cout << "Please choose a button from the menu\n";
			break;

		}

	} while (picked == false);
}

/*
***********************************
Welcome Function
***********************************
*/

void welcome()
{
	std::cout << "Welcome from Hungry-Man vending!\n\n\n";

	std::this_thread::sleep_for(std::chrono::milliseconds(5000));

	std::cout << "Please choose an item from our 5 categories\n\n\n";

	
	std::this_thread::sleep_for(std::chrono::milliseconds(5000));


	mainMenu();
}

/*
***********************************
Main Function just calls the welcome function and the rest is taken care of.
***********************************
*/

int main()
{

	welcome();
    return 0;
}

